"""Nonblocking UI/worker event trace; no motor or CAN access."""
from datetime import datetime,timezone,timedelta
from pathlib import Path
import json,queue,threading,time

class UiTrace:
    def __init__(self):
        folder=Path.home()/'bhl_logs/hand_gui';folder.mkdir(parents=True,exist_ok=True)
        self.path=folder/(datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d_%H%M%S_%f')+'.jsonl')
        self.q=queue.Queue(maxsize=2000);self.dropped=0;self.error=''
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def submit(self,event):
        entry={'utc':datetime.now(timezone.utc).isoformat(),'monotonic_s':time.monotonic(),**event}
        try:self.q.put_nowait(entry)
        except queue.Full:self.dropped+=1
    def run(self):
        with self.path.open('a',encoding='utf-8') as f:
            while True:
                entry=self.q.get()
                try:
                    if entry is None:return
                    f.write(json.dumps(entry,ensure_ascii=False,allow_nan=False)+'\n');f.flush()
                except Exception as exc:self.error=str(exc)
                finally:self.q.task_done()
    def close(self):
        self.q.put(None);self.thread.join(timeout=2)
