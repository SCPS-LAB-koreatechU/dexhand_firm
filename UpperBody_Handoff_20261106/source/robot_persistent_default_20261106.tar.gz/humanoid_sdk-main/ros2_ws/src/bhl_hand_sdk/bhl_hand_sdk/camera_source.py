"""MediaPipe Tasks camera worker. The child never imports or opens a CAN bus."""
import math
import queue
import time


def angle(a, b, c):
    u, v = [x-y for x, y in zip(a, b)], [x-y for x, y in zip(c, b)]
    length = math.sqrt(sum(x*x for x in u)*sum(x*x for x in v))
    if not math.isfinite(length) or length < 1e-10:
        raise ValueError("degenerate landmarks")
    cosine = max(-1.0, min(1.0, sum(x*y for x, y in zip(u, v))/length))
    return math.degrees(math.acos(cosine))


def fist_score(points):
    """Heuristic PIP/DIP flexion of four fingers, not robot joint calibration."""
    if len(points) != 21 or any(len(p) != 3 or any(not math.isfinite(x) for x in p) for p in points):
        raise ValueError("21 finite 3D landmarks required")
    curls = []
    for mcp in (5, 9, 13, 17):
        pip = angle(points[mcp], points[mcp+1], points[mcp+2])
        dip = angle(points[mcp+1], points[mcp+2], points[mcp+3])
        curls.append(max(0.0, min(1.0, (175.0-(pip+dip)/2)/90.0)))
    return sum(curls)/4


def offer_latest(output, value):
    try:
        output.put_nowait(value)
    except queue.Full:
        try:
            output.get_nowait()
        except queue.Empty:
            pass
        try:
            output.put_nowait(value)
        except queue.Full:
            pass


def camera_worker(output, stop, *, camera, model, headless=False, auto_arm=False, activity=None, max_age=.35, width=640, height=480, preview=None):
    capture = detector = None
    try:
        import cv2
        import mediapipe as mp
        from mediapipe.tasks import python
        from mediapipe.tasks.python import vision
        options = vision.HandLandmarkerOptions(base_options=python.BaseOptions(model_asset_path=model),
                    running_mode=vision.RunningMode.VIDEO, num_hands=2,
                    min_hand_detection_confidence=0.65, min_hand_presence_confidence=0.65,
                    min_tracking_confidence=0.65)
        detector = vision.HandLandmarker.create_from_options(options)
        source = int(camera) if str(camera).isdigit() else camera
        capture = cv2.VideoCapture(source)
        if not capture.isOpened():
            raise RuntimeError(f"cannot open USB camera {camera}")
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        last_ms, sequence, arm_at = -1, 0, 0.0
        closed = None
        smooth = None
        open_since = None
        auto_sent = False
        while not stop.is_set():
            captured_at = time.monotonic()
            ok, frame = capture.read()
            if not ok:
                raise RuntimeError("USB camera read failed")
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            stamp_ms = max(last_ms+1, int(captured_at*1000))
            last_ms = stamp_ms
            result = detector.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb), stamp_ms)
            # Two visible hands are ambiguous: do not silently switch people/hands.
            valid = len(result.hand_world_landmarks) == 1
            score = None
            if valid:
                points = [(p.x, p.y, p.z) for p in result.hand_world_landmarks[0]]
                try:
                    score = fist_score(points)
                except ValueError:
                    valid = False
                if valid:
                    smooth = score if smooth is None else .35*score + .65*smooth
                    if smooth < .25:
                        closed = False
                    elif smooth > .60:
                        closed = True
                    valid = closed is not None
            if not valid:
                smooth = closed = None
            now = time.monotonic()
            if valid and closed is False:
                open_since = now if open_since is None else open_since
            else:
                open_since = None
            if (auto_arm and not auto_sent and open_since is not None and now-open_since >= .5
                    and now-captured_at <= max_age):
                arm_at, auto_sent = now, True  # one deliberate headless enable only; never auto-rearm
            if preview is not None:
                view = cv2.flip(frame, 1)
                for landmarks in result.hand_landmarks:
                    pixels = [(int((1-p.x)*view.shape[1]), int(p.y*view.shape[0])) for p in landmarks]
                    for chain in ((0, 1, 2, 3, 4), (0, 5, 6, 7, 8), (5, 9, 10, 11, 12),
                                  (9, 13, 14, 15, 16), (13, 17, 18, 19, 20), (0, 17)):
                        for a, b in zip(chain, chain[1:]):
                            cv2.line(view, pixels[a], pixels[b], (70, 220, 80), 2)
                    for point in pixels:
                        cv2.circle(view, point, 3, (0, 180, 255), -1)
                image = cv2.cvtColor(cv2.resize(view, (480, 360)), cv2.COLOR_BGR2RGB)
                ppm = b'P6\n480 360\n255\n' + image.tobytes()
                offer_latest(preview, dict(ppm=ppm, captured_at=captured_at))
            if not headless:
                view = cv2.flip(frame, 1)
                label = "OPEN" if valid and closed is False else "CLOSED" if valid else "SHOW EXACTLY ONE HAND"
                cv2.putText(view, label, (15, 35), cv2.FONT_HERSHEY_SIMPLEX, .8, (0, 220, 0), 2)
                cv2.putText(view, "SPACE: arm/re-arm with open hand | H: HOLD | Q: quit", (12, 70),
                            cv2.FONT_HERSHEY_SIMPLEX, .48, (255, 255, 255), 1)
                state = activity.value if activity is not None else 0
                cv2.putText(view, "Robot: " + ("ACTIVE" if state == 1 else "HOLD" if state < 0 else "PREVIEW ONLY"),
                            (15, 105), cv2.FONT_HERSHEY_SIMPLEX, .65, (0, 220, 255), 2)
                cv2.imshow("DexHand CAN test - preview until SPACE", view)
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27) or cv2.getWindowProperty("DexHand CAN test - preview until SPACE", cv2.WND_PROP_VISIBLE) < 1:
                    offer_latest(output, dict(kind="quit"))
                    stop.set()
                    break
                if key == ord("h"):
                    # This control event is carried in every subsequent frame until a new arm key.
                    arm_at = -now
                if key == 32 and valid and closed is False:
                    arm_at = now
            sequence += 1
            offer_latest(output, dict(kind="frame", frame_id=sequence, captured_at=captured_at,
                                      valid=valid, closed=closed, score=score, arm_at=arm_at))
    except Exception as error:
        offer_latest(output, dict(kind="error", message=str(error)))
        stop.set()
    finally:
        if capture is not None:
            capture.release()
        if detector is not None:
            detector.close()
        if not headless:
            try:
                import cv2
                cv2.destroyAllWindows()
            except Exception:
                pass
